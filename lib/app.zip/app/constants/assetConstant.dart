class AssetConstant {

  /// AppLogo
  static const appSplash = "assets/logo/app_animated_logo.mp4";
  static const appLogo = "assets/logo/app_logo.png";
  static const appLogoSqr = "assets/logo/app_logo_sqr.png";

  /// User Onboarding
  static const userSelection = "assets/images/user_selection_img.png";
  static const user = "assets/images/user.png";

  static const arrowBack = "assets/images/arrow_back.png";

  /// Home Nav
  static const home = "assets/images/home.svg";
  static const category = "assets/images/category.svg";
  static const chat = "assets/images/chat.svg";
  static const reels = "assets/images/reels.svg";
  static const add = "assets/images/add.png";

  static const homeSelected = "assets/images/home_selected.svg";
  static const categorySelected = "assets/images/category_selected.svg";
  static const chatSelected = "assets/images/chat_selected.svg";
  static const reelsSelected = "assets/images/reels_selected.svg";
  static const shop = "assets/images/shop.svg";

  static const searchBarIcon = "assets/images/search.svg";
  static const favorite = "assets/images/favorite.svg";

  static const carTile = "assets/images/car_tile.png";
  static const bikeTile = "assets/images/bike_tile.png";
  static const evTile = "assets/images/ev_tile.png";
  static const commercialVehicleTile = 'assets/images/commercial_vehicle.png';
  static const heavyMechaneryTile = 'assets/images/heavy_mechanery.png';
  static const partsAccessories = 'assets/images/parts_accessories.png';
  static const servicesTile = 'assets/images/services_tile.png';
  static const luxeTile = 'assets/images/luxe_tile.png';
  static const comingSoonTile = 'https://carsandallweb.netlify.app/image/category/coming-soon.png';

  static const insuranceTile = 'assets/images/insurance_tile.png';
  static const moneyComingSoon = 'assets/images/money_coming_soon.png';
  static const rsaTile = 'assets/images/rsa_tile.png';
  static const vehicleAuctionTile = 'assets/images/vehicle_auction.png';
  static const marchendiseTile = 'assets/images/marchendise_tile.png';


  static const homeBanner = "assets/images/home_poster.png";
  static const car = "assets/images/car.png";
  static const bannerCar = "assets/images/car_banner.png";
  static const services = "assets/images/services.png";
  static const homePageBanner = "assets/images/home_page_banner.png";

  static const carDivider = "assets/images/car_divider.svg";

  static const videoThumbnail = "assets/images/video_thumbnail.png";
  static const brandLogo = "assets/images/brand_logo.png";
  static const emptySearch = "assets/images/empty_search_icon.png";

  static const carColorImage = "assets/images/car_color_image.png";

  static const pdfDownloadIcon = "assets/images/pdf_download_icon.png";
  static const personImage = "assets/images/person_img.png";
  static const carStarring = "assets/images/car_staring.svg";
  static const carIcon = "assets/images/car_icon.svg";
  static const dollarIcon = "assets/images/dollar_icon.svg";
  static const rightIcon = "assets/images/right_icon.svg";
  static const carImage = "assets/images/car_image.png";
  static const promoCodeIcon = "assets/images/promoCode_icon.png";

  static const cartIcon = "assets/images/cart_icon.png";

  static const securityIcon = "assets/images/security_icon.svg";
  static const dateIcon = "assets/images/date_icon.svg";
  static const mastercardImage = "assets/images/mastercard_image.png";

  static const documentIcon = "assets/images/document_icon.svg";
  static const carTileImage = "assets/images/car_tile_image.png";

  static const sortIcon = "assets/images/sort_icon.svg";

  static const bankImage = "assets/images/bank_image.png";

  static const chatIcon = "assets/images/chat_icon.svg";
  static const emiRestructureIcon = "assets/images/emi_restructure_icon.svg";
  static const loanRefinance = "assets/images/loan_refinance.svg";
  static const successIcon = "assets/images/success_icon.svg";

  static const moneyIcon = "assets/images/money_icon.svg";

  static const carIcon2 = "assets/images/car_icon2.svg";

  static const keyProfileIcon = "assets/images/key_profile_icon.svg";

  static const calenderIcon = "assets/images/calender_icon.svg";
  static const callingIcon = "assets/images/calling_icon.svg";
  static const buildingIcon = "assets/images/building_icon.svg";

  static const ideaIcon = "assets/images/idea_icon.svg";
  static const photoIcon = "assets/images/photo_icon.svg";
  static const carBreakdownIcon = "assets/images/car_breakdown_icon.svg";
  static const flatTyreIcon = "assets/images/flat_tyre_icon.svg";
  static const batteryIcon = "assets/images/battery_icon.svg";
  static const fuelIcon = "assets/images/fuel_icon.svg";

  static const filterIcon = 'assets/images/filter_icon.svg';

  static const clockIcon = 'assets/images/clock_icon.svg';
  static const trustIcon = 'assets/images/trust_icon.svg';

  static const serviceIcon = 'assets/images/service_icon.svg';

  static const bellIcon = "assets/images/bell_icon.svg";
  static const personIcon = "assets/images/person_icon.svg";

  static const appSplashLogo = 'assets/logo/app_splash_logo.png';
  static const comingSoon = 'assets/images/coming_soon.gif';
  static const servicesCarImage = 'assets/images/service_car_image.png';

  static const moneyBagIcon = 'assets/images/money_bag_icon.svg';

  static const cibilPointerRed = 'assets/images/cibil_pointer_red.svg';

  static const cibilMetreImage = 'assets/images/cibil_metre_image.png';

}